let stdRoll=prompt("Enter your Roll");
let stdReg=prompt("Enter your Regestion");

studentName.forEach((item,index)=>{
    if(studentRoll[index]==stdRoll && studentReg[index]==stdReg){

        console.log(
            `
            name:${item};
            Roll:${studentRoll[index]};
            Reg:${studentReg[index]};
            ==============================
            sub->Mark->Gpa->Grade 
            Ban->${ban[index]}->${getGpa(ban[index])}->${getGrade(ban[index])};
            Eng->${eng[index]}->${getGpa(eng[index])}->${getGrade(eng[index])};
            Math->${math[index]}->${getGpa(math[index])}->${getGrade(math[index])};
            Science->${science[index]}->${getGpa(science[index])}->${getGrade(science[index])};
            Social->${social[index]}->${getGpa(social[index])}->${getGrade(social[index])};
            Religion->${religion[index]}->${getGpa(religion[index])}->${getGrade(religion[index])};
            ==============================
            Status: ${isPassed(index)};
            
            `
            
            
            
            
            );
    }

})