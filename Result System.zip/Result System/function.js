//80=5.00  -> A+
// 70=4.00 -> A
// 60=3.50  ->A-
// 50=3.00  ->B
// 40=2.50 -> C
// 33=2.00 -> D
// under 33=0 -> F
const getGpa=(mark)=>{
    let gpa;
    if(mark>=80){
        gpa=5.00;
    }
    else if(mark>=70){
        gpa=4.00;
    }
    else if(mark>=60){
        gpa=3.50;
    }
    else if(mark>=50){
        gpa=3.00;
    }
    else if(mark>=40){
        gpa=2.50;
    }
    else if(mark>=33){
        gpa=2.00;
    }
    else{
        gpa=0;
    }

    return gpa;
}

const getGrade=(mark)=>{
    let grade;
    if(mark>=80){
        grade= "A+";
    }
    else if(mark>=70){
        grade=" A";
    }
    else if(mark>=60){
        grade= "A-";
    }
    else if(mark>=50){
        grade= "B";
    }
    else if(mark>=40){
        grade="C";
    }
    else if(mark>=33){
        grade="D";
    }
    else{
        grade="F";
    }

    return grade;
}
let ispassed=(s1,s2,s3,s4,s5,s6)=>{
 if(s1>33&&s2>=33&&s3>33&&s4>=33&&s5>33&&s6>=33){
    return true;
 }
 else{
    return false;
 }
}
//console.log(ispassed(45,78,67,78,56,56));


let totalGpa=(s1,s2,s3,s4,s5,s6)=>{
   let finalGpa= getGpa(s1)+getGpa(s2)+getGpa(s3)+getGpa(s4)+getGpa(s5)+getGpa(s6);

   return finalGpa/6;
}

function isPassed(index) {
    let subjects = [ban[index], eng[index], math[index], science[index], social[index], religion[index]];
    return subjects.every(mark => mark >= 33) ? 'Passed' : 'Failed';
}
