const slides = document.querySelectorAll('.slide');
let currentSlide = 0;
let slideInterval;

function showSlide(index) {
  slides.forEach((slide, i) => {
    slide.classList.toggle('active', i === index);
  });
}

function changeSlide(direction) {
  currentSlide = (currentSlide + direction + slides.length) % slides.length;
  showSlide(currentSlide);
  resetAutoSlide(); // reset timer on manual click
}

function autoSlide() {
  currentSlide = (currentSlide + 1) % slides.length;
  showSlide(currentSlide);
}

function resetAutoSlide() {
  clearInterval(slideInterval);
  slideInterval = setInterval(autoSlide, 3000); // Change every 3 seconds
}

// Initialize
showSlide(currentSlide);
slideInterval = setInterval(autoSlide, 3000);

